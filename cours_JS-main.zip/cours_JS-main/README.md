JS_JSduzero

Cours de JS  de Javascript du Zero
<br> Le site est excellent pour se lancer : https://www.javascriptdezero.com/
<br> Le youtube : https://www.youtube.com/channel/UCMzJVrWeaKUotLPWTdx6HuQ
<br> Le GitHub : https://github.com/javascriptdezero

Cours de JS de From Scratch
<br> Youtube : https://www.youtube.com/watch?v=9OJLxDxyNg4&t=1403s&ab_channel=FromScratch-D%C3%A9veloppementWeb


