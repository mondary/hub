// Une variable qui ne bougera pas est un CONST
const prenom = "Justine";

console.log(prenom);

prenom = "Tristan";
