console.log("Hello");

// Pour initialiser une variable unTexte, qui contiendra comme valeur Voici un texte
var unTexte = "Voici un texte";

// console.log permet d'afficher dans la console la valeur de unTexte
console.log(unTexte);

// Une fois cette variable initialisée, déclaré, on peut la rappeler et lui donner une nouvelle valeur
unTexte = "Un nouveau texte ...";

console.log(unTexte);
